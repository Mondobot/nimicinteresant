package mediator;

import java.util.ArrayList;

import controller.Controller;

import model.*;

public class Mediator implements IMediator{
	Controller controller;
	
	public Mediator(Controller controller) {
		this.controller = controller;
	}
	
	//todo implement for the version 2.0
	public void registerUser(String username) {
		
	}

	//todo implement for the version 2.0
	public void getUsers() {
		
	}
	
	//todo implement for the version 2.0
	public void getFiles(Integer userID) {
		
	}
	
	//todo implement for the version 2.0
	public void getTransfers(Integer userID) {
		
	}
	
	public void updateTransfer(Transfer newTransfer) {
		
	}
	
	
}